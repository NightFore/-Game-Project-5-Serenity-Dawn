--------------------Credits--------------------------
------People who worked on the project:
NightFore : Programmer, Writer, Level & Balance Design, Artist (Character, Background)
Yude95 : Balance Design, Artist (Background)
Eldao : Artist (Monster)

------Ressources :
BGM/SFX : http://en.maoudamashii.com/